/**
 * 
 */
package boardgame;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author JackBoston
 *
 */
public class GameInterfaceTheBoard {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("Welcome to Rich Uncle Penny Bags goes Green. The Sustainable "
				+ "monopoly based boardgame, without the board ;).");
		
		boolean gameCompleted= false;
		Player player1 = new Player();
		Player player2 = new Player();
		Player player3 = new Player();
		Player player4 = new Player();
		
		ArrayList<Player> players = new ArrayList<Player>();
		
		players.add(player1);
		players.add(player2);
		players.add(player3);
		players.add(player4);
		
		Square Start = new Square(0,0, null);
		TidalSquare One = new TidalSquare(1, null,500);
		TidalSquare Two = new TidalSquare(2, null,500);
		TidalSquare Three = new TidalSquare(3, null,500);
		NuclearSquare Four = new NuclearSquare(4, null,500);
		NuclearSquare Five = new NuclearSquare(5, null,500);
		SolarSquare Six = new SolarSquare(6, null,500);
		SolarSquare Seven = new SolarSquare(7, null,500);
		WindSquare Eight = new WindSquare(8, null,500);
		WindSquare Nine = new WindSquare(9, null,500);
		WindSquare Ten = new WindSquare(10, null,500);
		Square Eleven = new Square(11,0, null);
		
		ArrayList<Square> board = new ArrayList<Square>();
		
		board.add(Start);
		board.add(One);
		board.add(Two);
		board.add(Three);
		board.add(Four);
		board.add(Five);
		board.add(Six);
		board.add(Seven);
		board.add(Eight);
		board.add(Nine);
		board.add(Ten);
		board.add(Eleven);
		
		String user;
		Scanner sc = new Scanner(System.in);
		do {
		for (Player player : players) {
		System.out.println("Are you ready for your turn? (Y/N).");
		user =sc.next();
		
		if (user.equalsIgnoreCase("Y")) {
			takeTurn(player,board);
			
		} else {
			System.out.println("Ok. Do you want to invest? (Y/N)");
			user=sc.next();
			
			if(user.equalsIgnoreCase("Y")) {
				
			} else {
				continue;
				
			}//end  of imbedded else
			
		}//end of else 
		
		}//end of for 
		
		} while (!gameCompleted);	
		
		sc.close();
	}//end of main
	
	public static void takeTurn (Player player,ArrayList<Square>board) {
		
		 player.throwDice();
		
		for (Square square : board) {
			square.squareAddOrRemove(player);
			
			if (square.getNumber()==player.throwDice()){
				
				System.out.println("This is a "+square.getClass());
			}
			
		}
		
	}//end of method 
	
	public static void playerInvests  (Player player, ArrayList<Square>board) {
		
		int user;
		String userStr;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What square would you like to buy or develope on? Enter the number between 1 and 10.");
		user=sc.nextInt();
	
		
	for (Square square : board) {
		if (square.getNumber()==user) {
		System.out.println("This square costs "+square.getPrice());	
		System.out.println("You have "+player.getResources());
		System.out.println("Do you want to buy? (Y/N)");
		userStr=sc.next();
		
		if ((userStr.equalsIgnoreCase("Y"))&&(player.getResources()>=square.getPrice())) {
			player.removeResources(square.getPrice());
			player.addSquare(square);
			
		} else {
			System.out.println("The transaction did not go through. You still have your resources.");
			System.out.println("Resources are "+player.getResources());
		
		}
		
	}
		}
		
	}

}//end of class
