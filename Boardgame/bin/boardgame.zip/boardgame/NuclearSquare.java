/**
 * 
 */
package boardgame;

/**
 * @author JackBoston
 *
 */
public class NuclearSquare extends Square implements Development  {

	private String owner;
	private double price;
	/**
	 * Default Constructor
	 */
	public NuclearSquare () {
		
	}
	
	/**
	 * @param number
	 */
	public NuclearSquare(int number, String owner, double price) {
		super(number,price,owner);
		
	}

	@Override
	public void Develope(boolean levelOne, boolean levelTwo, boolean levelThree, boolean levelFour) {
		
		if (levelOne==true) {
			System.out.println("Congratulations on your Level One Nuclear Development");
		}
		else if (levelTwo==true) {
		System.out.println("Congratulations on your Level Two Nuclear Development");
		}
		else if (levelThree==true) {
			System.out.println("Congratulations on your Level Three Nuclear Development");
		}
		else if (levelFour==true) {
			System.out.println("Congratulations on your Level Four Nuclear Development");
		}
		else {
			System.out.println("Sorry that didnt work out.");
		}
		
	}
}
