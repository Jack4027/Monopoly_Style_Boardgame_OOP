/**
 * 
 */
package boardgame;

import java.util.LinkedList;

/**
 * @author JackBoston
 *
 */
public class Square {
	
	private int squareNumber; 
	private LinkedList<Player> playersOnSquare;
	private double price;
	private String owner;
	
	/**
	 * Default Constructor
	 */
	public Square () {
		
	}
	
	/**
	 * Constructor with args
	 * @param number
	**/
	
	public Square(int number, double price, String owner) {
		this.squareNumber = number;
		this.setPrice(price);
		this.setOwner(owner);
		
	}

	/**
	 * @return the number
	 */
	
	public int getNumber() {
		return squareNumber;
	}
	
	/**
	 * @param number the number to set
	 */
	
	public void setNumber(int number) {
		this.squareNumber = number;
	}

	/**
	 * @return the playersOnSquare
	 */
	public LinkedList<Player> getPlayersOnSquare() {
		return playersOnSquare;
	}

	/**
	 * @param playersOnSquare the playersOnSquare to set
	 */
	public void setPlayersOnSquare(LinkedList<Player> playersOnSquare) {
		this.playersOnSquare = playersOnSquare;	

}


	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	public void squareAddOrRemove (Player player) {
		
		if (Player.getCurrentSquare()==squareNumber) {
			playersOnSquare.add(player);
			
		} else if (Player.getCurrentSquare()!=squareNumber) {
			playersOnSquare.remove(player);
		}
		
	}
	
	public void StartSquare(Player player) {
		
		if (Player.getCurrentSquare()+Player.throwDice()>12) {
			System.out.println(player.getName()+" you've done a lap of the suatainability circuit so you get 200"
					+ "\n carbon credits. Congratulations, balances were "+player.getResources()+
					"CC.");
			player.addResources(200.00);
			System.out.println("Resources are now......."+player.getResources());
			
		}
		
	}
	
}