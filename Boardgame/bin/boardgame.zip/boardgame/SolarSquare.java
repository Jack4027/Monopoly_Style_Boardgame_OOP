/**
 * 
 */
package boardgame;

/**
 * @author JackBoston
 *
 */
public class SolarSquare extends Square implements Development {
	


	/**
	 * Default Constructor
	 */
	public SolarSquare () {
		
	}
	
	/**
	 * @param number
	 */
	public SolarSquare(int number, String owner,double price) {
		super(number,price,owner);
		
		
	}



	@Override
	public void Develope(boolean levelOne, boolean levelTwo, boolean levelThree, boolean levelFour) {
		
		if (levelOne==true) {
			System.out.println("Congratulations on your Level One Solar Development");
		}
		else if (levelTwo==true) {
		System.out.println("Congratulations on your Level Two Solar Development");
		}
		else if (levelThree==true) {
			System.out.println("Congratulations on your Level Three Solar Development");
		}
		else if (levelFour==true) {
			System.out.println("Congratulations on your Level Four Solar Development");
		}
		else {
			System.out.println("Sorry that didnt work out.");
		}
	}

	
	
	

}
