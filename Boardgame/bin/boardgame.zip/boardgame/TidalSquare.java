/**
 * 
 */
package boardgame;

/**
 * @author JackBoston
 *
 */
public class TidalSquare extends Square implements Development {
	
	private String owner;
	
	
	/**
	 * Default Constructor
	 */
	public TidalSquare () {
		
	}
	
	
	
	/**
	 * @param number
	 */
	public TidalSquare(int number, String owner,double price) {
		super(number,price, owner);
		
	
	}


	@Override
	public void Develope(boolean levelOne, boolean levelTwo, boolean levelThree, boolean levelFour) {
		
		if (levelOne==true) {
			System.out.println("Congratulations on your Level One Tidal Development");
			
		}
		else if (levelTwo==true) {
		System.out.println("Congratulations on your Level Two Tidal Development");
		}
		else if (levelThree==true) {
			System.out.println("Congratulations on your Level Three Tidal Development");
		}
		else if (levelFour==true) {
			System.out.println("Congratulations on your Level Four Tidal Development");
		}
		else {
			System.out.println("Sorry that didnt work out.");
		}
		
	}


	
}
