/**
 * 
 */
package boardgame;

import java.util.LinkedList;
import java.util.Random;

/**
 * @author JackBoston
 *
 */
public class Player {
	
	private String name; 
	public static int currentSquare;
	private double resources;
	private LinkedList<Square>squaresOwned;
	
	
	
	
	/**
	 * Default Constructor
	 */
	public Player() {
		
	}

	/**
	 * @return the name
	 */
	
	public String getName() {
		return name;
	}
	
	/**
	 * @param name the name to set
	 */
	
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the currentSquare
	 */
	
	public static int getCurrentSquare() {
		return currentSquare;
	}
	
	/**
	 * @param currentSquare the currentSquare to set
	 */
	
	public void setCurrentSquare(int currentSquare) {
		Player.currentSquare = currentSquare;
	}
	

	/**
	 * @return the resources
	 */
	public double getResources() {
		return resources;
	}

	/**
	 * @param resources the resources to set
	 */
	public void setResources(double resources) {
		this.resources = resources;
	}
	/**
	 * @return the squares
	 */
	public LinkedList<Square> getSquares() {
		return squaresOwned;
	}

	/**
	 * @param squares the squares to set
	 */
	public void setSquares(LinkedList<Square> squares) {
		this.squaresOwned = squares;
	}
	
	public void addSquare (Square square) {
		
		this.squaresOwned.add(square);
		
		square.setOwner(this.getName());
	}
	
	
	
	public double addResources (double amount) {
		
		System.out.println("Resources before are "+this.resources);
		this.resources= this.resources+amount;
		System.out.println("resources after are "+this.resources);
		return this.resources;
	}
	
	public double removeResources (double amount ) {
		
		System.out.println("Resources before are "+this.resources);
		this.resources= this.resources-amount;
		System.out.println("Resources after are "+this.resources);
		return this.resources;
	}

	public static int throwDice () {
	
	
		
		Random rand = new Random();
		
		System.out.println("You are on square "+currentSquare);
		
		int throw1 = rand.nextInt(6);
		
		System.out.println("Your first throw was a "+throw1);
		
		int throw2 = rand.nextInt(6);
		
		System.out.println("Your second throw was a "+throw2);
		
		int result = throw1+throw2;
		
		System.out.println("Combined you threw a "+ result);
		
		currentSquare=currentSquare+result;
		
		if (currentSquare>12) {
			currentSquare=currentSquare-12;
		}
		
		System.out.println("You are now on square "+currentSquare);
	
		return result;
	}
}
