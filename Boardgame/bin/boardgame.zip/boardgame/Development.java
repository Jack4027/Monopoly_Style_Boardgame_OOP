/**
 * 
 */
package boardgame;

/**
 * @author JackBoston
 *
 */
public interface Development {

	public void Develope(boolean levelOne,boolean levelTwo,boolean levelThree,boolean levelFour);
	
}
