/**
 * 
 */
package boardgame;

/**
 * @author JackBoston
 *
 */
public class WindSquare extends Square implements Development{
	
	private String owner;
	

	/**
	 * Default Constructor
	 */
	public WindSquare () {
		
	}
	
	/**
	 * @param number
	 */
	public WindSquare(int number, String owner, double price) {
		super(number,price,owner);
		
	}


	@Override
	public void Develope(boolean levelOne, boolean levelTwo, boolean levelThree, boolean levelFour) {
		
		if (levelOne==true) {
			System.out.println("Congratulations on your Level One Wind Development");
			
		}
		else if (levelTwo==true) {
		System.out.println("Congratulations on your Level Two Wind Development");
		}
		else if (levelThree==true) {
			System.out.println("Congratulations on your Level Three Wind Development");
		}
		else if (levelFour==true) {
			System.out.println("Congratulations on your Level Four Wind Development");
		}
		else {
			System.out.println("Sorry that didnt work out.");
		}
		
	}

}
